//
//  QuizAPI.swift
//  quiz
//
//  Created by Domenico Majorana on 11/08/2019.
//  Copyright © 2019 Domenico Majorana. All rights reserved.
//

import Foundation

class QuizAPI {
    private var questionsList:[Question] = []
    
    func getQuestions(completion: @escaping (Result<[Question], Error>) -> Void) {
        guard let url = URL(string: "https://opentdb.com/api.php?amount=10&type=multiple&encode=url3986") else { return }
        
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            guard let data = data else { return }
            do {
                let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
                let questionsList: NSArray = (json!["results"] as? NSArray)!
                
                for i in 0..<questionsList.count {
                    let question: NSDictionary = questionsList[i] as! NSDictionary
                    
                    let correctAnswer = (question["correct_answer"] as AnyObject).removingPercentEncoding!
                    
                    var allAnswers = [correctAnswer]
                    
                    let incorrectAnswers: NSArray = (question["incorrect_answers"] as? NSArray)!
                    for i in 0..<incorrectAnswers.count {
                        allAnswers.append((incorrectAnswers[i] as AnyObject).removingPercentEncoding!)
                    }
                    
                    let currentQuestion = Question(text: (question["question"] as AnyObject).removingPercentEncoding! as String, correctAnswer: correctAnswer!, answers: allAnswers.shuffled() as! [String])
                    
                    self.questionsList.append(currentQuestion)
                }
                
                DispatchQueue.main.async {
                    completion(.success(self.questionsList))
                }
                
            } catch {
                print("JSON error: \(error.localizedDescription)")
            }
        }.resume();
    }
}
