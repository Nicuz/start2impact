//
//  Question.swift
//  quiz
//
//  Created by Domenico Majorana on 09/08/2019.
//  Copyright © 2019 Domenico Majorana. All rights reserved.
//

import Foundation

public class Question {
    private var text:String?
    private var correctAnswer:String?
    private var answers = [String?]()
    
    var getText:String {
        get {
            return self.text!
        }
    }
    
    var getCorrectAnswer:String {
        get {
            return self.correctAnswer!
        }
    }
    
    var getAnswers:[String] {
        get {
            return self.answers as! [String]
        }
    }
    
    init(text: String, correctAnswer: String, answers: [String]) {
        self.text = text
        self.correctAnswer = correctAnswer
        self.answers = answers
    }
}
