//
//  RoundedButton.swift
//  quiz
//
//  Created by Domenico Majorana on 11/08/2019.
//  Copyright © 2019 Domenico Majorana. All rights reserved.
//

import UIKit

@IBDesignable class RoundedButton: UIButton
{
    override func layoutSubviews() {
        super.layoutSubviews()

        updateCornerRadius()
        numberOfLines()
    }

    @IBInspectable var rounded: Bool = false {
        didSet {
            updateCornerRadius()
        }
    }

    func updateCornerRadius() {
        layer.cornerRadius = rounded ? frame.size.height / 2 : 0
    }
    
    func numberOfLines() {
        titleLabel!.numberOfLines = 2
    }
}
