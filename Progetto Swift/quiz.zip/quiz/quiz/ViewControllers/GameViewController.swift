//
//  GameViewController.swift
//  quiz
//
//  Created by Domenico Majorana on 11/08/2019.
//  Copyright © 2019 Domenico Majorana. All rights reserved.
//

import UIKit

class GameViewController: UIViewController {
    let gameViewModel: GameViewModel = GameViewModel()
    
    func toggleButtonsStatus(_ status: Bool) {
        answer1.isEnabled = status
        answer2.isEnabled = status
        answer3.isEnabled = status
        answer4.isEnabled = status
        
        if (status) {
            nextButton.isHidden = true
            let defaultColor:UIColor = UIColor(red: 141.0/255, green: 148.0/255, blue: 187.0/255, alpha: 1.0)
            answer1.backgroundColor = defaultColor
            answer2.backgroundColor = defaultColor
            answer3.backgroundColor = defaultColor
            answer4.backgroundColor = defaultColor
        }
    }
    
    func highlightCorrectAnswer(_ index: Int) {
        let green:UIColor = UIColor(red: 0.4, green: 1.0, blue: 0.2, alpha: 0.5)
        
        switch (index) {
        case 0:
            answer1.backgroundColor = green
            break
        case 1:
            answer2.backgroundColor = green
            break
        case 2:
            answer3.backgroundColor = green
            break
        case 3:
            answer4.backgroundColor = green
            break
        default:
            break
        }
    }
    
    func checkAnswer(index: Int) {
        let green:UIColor = UIColor(red: 0.4, green: 1.0, blue: 0.2, alpha: 0.5)
        let red:UIColor = UIColor(red: 1.0, green: 0, blue: 0, alpha: 0.5)
        nextButton.isHidden = false
        
        let selectedAnswer = self.gameViewModel.questionsList[self.gameViewModel.questionNumber-1].getAnswers[index]
        let correctAnswer = self.gameViewModel.questionsList[self.gameViewModel.questionNumber-1].getCorrectAnswer
        
        let correctAnswerIndex:Int = self.gameViewModel.questionsList[self.gameViewModel.questionNumber-1].getAnswers.firstIndex(of: correctAnswer)!
        
        if (self.gameViewModel.isCorrect(answer: selectedAnswer, correctAnswer: correctAnswer)) {
            toggleButtonsStatus(false)
            self.gameViewModel.score += 1
            switch (index) {
            case 0:
                answer1.backgroundColor = green
                break
            case 1:
                answer2.backgroundColor = green
                break
            case 2:
                answer3.backgroundColor = green
                break
            case 3:
                answer4.backgroundColor = green
                break
            default:
                break
            }
            
        } else {
            toggleButtonsStatus(false)
            highlightCorrectAnswer(correctAnswerIndex)
            switch (index) {
            case 0:
                answer1.backgroundColor = red
                break
            case 1:
                answer2.backgroundColor = red
                break
            case 2:
                answer3.backgroundColor = red
                break
            case 3:
                answer4.backgroundColor = red
                break
            default:
                break
            }
            
        }
    }
    @IBOutlet weak var questionNumberLabel: UILabel!
    
    @IBOutlet weak var questionTextLabel: UILabel!
    @IBOutlet weak var answer1: RoundedButton!
    @IBAction func selected1(_ sender: Any) {
        checkAnswer(index: 0)
    }
    @IBOutlet weak var answer2: RoundedButton!
    @IBAction func selected2(_ sender: Any) {
        checkAnswer(index: 1)
    }
    @IBOutlet weak var answer3: RoundedButton!
    @IBAction func selected3(_ sender: Any) {
        checkAnswer(index: 2)
    }
    @IBOutlet weak var answer4: RoundedButton!
    @IBAction func selected4(_ sender: Any) {
        checkAnswer(index: 3)
    }
    @IBOutlet weak var nextButton: RoundedButton!
    @IBAction func nextQuestion(_ sender: Any) {
        if (self.gameViewModel.questionNumber < 10) {
            toggleButtonsStatus(true)
            gameViewModel.nextQuestion()
            
            questionNumberLabel.text = gameViewModel.getQuestionNumberLabel
            self.questionTextLabel.text = self.gameViewModel.questionsList[self.gameViewModel.questionNumber-1].getText
            self.answer1.setTitle(self.gameViewModel.questionsList[self.gameViewModel.questionNumber-1].getAnswers[0], for: .normal)
            self.answer2.setTitle(self.gameViewModel.questionsList[self.gameViewModel.questionNumber-1].getAnswers[1], for: .normal)
            self.answer3.setTitle(self.gameViewModel.questionsList[self.gameViewModel.questionNumber-1].getAnswers[2], for: .normal)
            self.answer4.setTitle(self.gameViewModel.questionsList[self.gameViewModel.questionNumber-1].getAnswers[3], for: .normal)
        } else {
            let alertView = UIAlertController(title: "Score",
                                              message: "\(self.gameViewModel.score)/10",
                                              preferredStyle: .alert)
            let okAction = UIAlertAction(title: "Go back to home", style: .default) {
                UIAlertAction in
                self.dismiss(animated: true, completion: nil)
            }
            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel)
            alertView.addAction(okAction)
            alertView.addAction(cancelAction)
            present(alertView, animated: true, completion: nil)
        }
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        nextButton.isHidden = true
        questionNumberLabel.text = gameViewModel.getQuestionNumberLabel
        gameViewModel.getQuestions { results in
            switch results {
            case .success(let questionArray):
                self.gameViewModel.questionsList = questionArray
                self.questionTextLabel.text = questionArray[self.gameViewModel.questionNumber-1].getText
                self.answer1.setTitle(questionArray[self.gameViewModel.questionNumber-1].getAnswers[0], for: .normal)
                self.answer2.setTitle(questionArray[self.gameViewModel.questionNumber-1].getAnswers[1], for: .normal)
                self.answer3.setTitle(questionArray[self.gameViewModel.questionNumber-1].getAnswers[2], for: .normal)
                self.answer4.setTitle(questionArray[self.gameViewModel.questionNumber-1].getAnswers[3], for: .normal)
                
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
}
