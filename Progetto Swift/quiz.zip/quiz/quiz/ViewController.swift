//
//  ViewController.swift
//  quiz
//
//  Created by Domenico Majorana on 08/08/2019.
//  Copyright © 2019 Domenico Majorana. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

