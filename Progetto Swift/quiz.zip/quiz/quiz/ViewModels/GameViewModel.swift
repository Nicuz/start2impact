//
//  GameViewModel.swift
//  quiz
//
//  Created by Domenico Majorana on 11/08/2019.
//  Copyright © 2019 Domenico Majorana. All rights reserved.
//

import UIKit

public final class GameViewModel {
    public var score = 0;
    public var questionNumber = 1;
    public var questionsList:[Question] = []
    
    func getQuestions(completion: @escaping (Result<[Question], Error>) -> Void) {
        let api:QuizAPI = QuizAPI()
        
        api.getQuestions { results in
            switch results {
            case .success(let prova):
                DispatchQueue.main.async {
                    self.questionsList = prova
                    completion(.success(self.questionsList))
                }
                
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    var getQuestionNumberLabel:String {
        get {
            return "Question \(self.questionNumber)"
        }
    }
    
    func nextQuestion() {
        if (self.questionNumber < 10) {
            self.questionNumber += 1
        }
    }
    
    func isCorrect(answer:String, correctAnswer:String) -> Bool {
        return answer == correctAnswer ? true : false
    }
}
